       Challenge: Design — "Command & Control Beacon"
Scenario: Evidence suggests the rogue drone was receiving commands from a hidden server. Network logs and flight data contain traces of the drone's Command & Control (C2) infrastructure.
Mission Objective: Identify the C2 server domain by analysing network logs and cross-referencing with OSINT techniques.
Available Artifacts:
    (a) Network logs (implied from previous challenges or provided separately)
    (b) Flight data logs
Tasks:
    (a) Scan network logs for unusual IP addresses or domains communicating with the drone
    (b) Look for specific command structures or protocol initiations indicative of C2 traffic
    (c) Cross-reference suspicious domains to confirm the C2 infrastructure
Flags:
    (a) Flag 1: The domain name of the C2 server (FLAG{C2_domain})



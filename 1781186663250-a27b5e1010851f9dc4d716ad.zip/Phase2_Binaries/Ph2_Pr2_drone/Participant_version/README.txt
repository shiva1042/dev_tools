﻿       Challenge: Grounded - Rogue Signal Intercept
Scenario: A suspicious flight was detected, and network traffic was captured during the event. The packet capture (rogue_signal.pcap) is fragmented and contains a mix of standard telemetry and anomalous data.
Mission Objective: Analyse the network traffic to identify the communication protocol, port, and the sensitive information being transmitted.
Available Artifacts: rogue_signal.pcap
Tasks:
    (a) Load the packet capture and filter for non-standard traffic.
    (b) Identify the communication protocol and port used by the rogue drone.
    (c) Isolate the specific piece of sensitive information being transmitted in the payload.
Flags:
    (a) Flag 1: The sensitive information uncovered in the network traffic (FLAG{...})



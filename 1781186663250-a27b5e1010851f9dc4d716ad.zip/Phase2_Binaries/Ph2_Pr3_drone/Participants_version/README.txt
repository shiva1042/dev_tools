﻿Challenge: Grounded - Firmware Footprints
Scenario: A small section of the BigCorp X7 drone's firmware (firmware_snippet_arm) was recovered. This snippet handles initialization and communication setup. Analysis suggests a hardcoded secret string was left for internal authentication.
Mission Objective: Reverse-engineer the ARM binary to locate the hardcoded secret used for internal protocols.
Available Artifacts: firmware_snippet_arm
Tasks:
    (a) Disassemble and analyse the ARM binary
    (b) Search for hardcoded strings, specifically those related to authentication or communication handshakes
    (c) Identify the secret string hidden within the logic
Flags:
    (a) Flag 1: The hardcoded secret string found in the firmware (FLAG{...})




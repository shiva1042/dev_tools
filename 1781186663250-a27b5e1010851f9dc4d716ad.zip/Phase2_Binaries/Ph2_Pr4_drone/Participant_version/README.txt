﻿       Challenge: Grounded - GPS Hijinks
Scenario: Several GPS log files from BigCorp drones have been recovered. One log exhibits highly suspicious activity, indicating potential GPS spoofing or data manipulation.
Mission Objective: Identify the anomalous flight log, pinpoint the manipulation, and extract the flag hidden within the data.
Available Artifacts: gps_logs/ directory (Multiple .csv files)
Tasks:
    (a) Analyse the CSV files to identify the log with impossible jumps, illogical paths, or data inconsistencies
    (b) Investigate the anomalous data points
    (c) Extract the flag located in the 'Note' column near the anomaly or derive it from the manipulated data
Flags:
    (a) Flag 1: The secret flag uncovered from the manipulated GPS log (FLAG{...})

